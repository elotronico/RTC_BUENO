#define led 13
//-----------------------------------------------------
//---	    		TECLAS DEL TECLADO				---
//-----------------------------------------------------
#define delayPulsacion 160

#define btnUp 35
#define btnDown 39
#define btnOk 45
#define btnCancel 47



//-----------------------------------------------------
//---	    			astronomico.ino				---
//-----------------------------------------------------
// what is our longitude (west values negative) and latitude (south values negative)
float const LATITUDE = 42.22;
float const LONGITUDE = -8.81;
int zonaHoraria = 1;

uint8_t tablaOrtoOcaso[4] = {0,0,0,0};

#define horaAmanece tablaOrtoOcaso[0]
#define minutoAmanece tablaOrtoOcaso[1]

#define minutoAnochece tablaOrtoOcaso[2]
#define horaAnochece tablaOrtoOcaso[3]


//-----------------------------------------------------
//---		tabla de horarios de encendidos		    ---
//-----------------------------------------------------


/*
*	0 -> enable/disable [On(1),Off(0)] - indica si el programa esta habilitado o deshabilitado
*	1 -> Salida [1~8]- indica la salida sobre la que actua
*	2 -> Accion [On(1), Off(0)] - indica si activa o desactiva la salida indicada
*	3 -> Tipo horario [astronomico(1), Hora fija(2)] - indica si funciona con el horario astronomico o por horario fijo
*	4 -> On_Hora [00~23] - Hora de encendido para este circuito
*	5 -> On_Minuto [00~59]- minuto de encendido
*	6 -> On_Adelanto/Atraso - adelanto atraso para el encendido de este circuito
*	7 -> Off_Hora - Hora de apagado para este circuito
*	8 -> Off_Minuto - minuto de apagado
*	9 -> Off_Adelanto/Atraso - adelanto atraso para el apagado de este circuito
*	
*/


#define habilitado 1
#define deshabilitado 0

#define Astron 1
#define hFija 2

#define astro_astro 1
#define hFija_hFija 2
#define astro_hFija 3
#define hFija_astro 4

#define horarioEnable  (uint8_t)0	//indica si esta habilitado o no
#define horarioCircuito (uint8_t)1	//indica sobre que circuito actua
#define horarioTipo (uint8_t)2		//indica el funcionamiento [Astro-Astro][Hora-Hora][Astro-Hora][Hora-Astro]

#define horarioAdelantoEncendido (uint8_t)3		//adelanto-atraso sobre el encendido
#define horarioHoraEncendido (uint8_t)4			//hora en la que enciende
#define horarioMinutoEncendo (uint8_t)5			//minuto en el que enciende

#define horarioAdelantoApagado (uint8_t)6		//adelanto-atraso sobre el apagado
#define horarioHoraApagado (uint8_t)7			//hora en la que apaga
#define horarioMinutoApagado (uint8_t)8			//minuto en el que apaga



//un total de 180 posiciones
uint8_t tablaHorarioEncendidos[20][20]={
		{1, 1, 1, 1, 1, 1, 1, 1, 1},		//1
		{0, 2, 1, 1, 1, 1, 1, 1, 1},		//2
		{1, 3, 1, 1, 1, 1, 1, 1, 1},		//3
		{1, 4, 1, 1, 1, 1, 1, 1, 1},		//4
		{1, 5, 1, 1, 1, 1, 1, 1, 1},		//5
		{0, 6, 1, 1, 1, 1, 1, 1, 1},		//6
		{0, 7, 1, 1, 1, 1, 1, 1, 1},		//7
		{1, 8, 1, 1, 1, 1, 1, 1, 1},		//8
		{1, 9, 1, 1, 1, 1, 1, 1, 1},		//9
		{1, 10, 1, 1, 1, 1, 1, 1, 1},		//11
		{1, 11, 1, 1, 1, 1, 1, 1, 1},		//11
		{1, 12, 1, 1, 1, 1, 1, 1, 1},		//12
		{1, 13, 1, 1, 1, 1, 1, 1, 1},		//13
		{1, 14, 1, 1, 1, 1, 1, 1, 1},		//14
		{1, 15, 1, 1, 1, 1, 1, 1, 1},		//15
		{1, 16, 1, 1, 1, 1, 1, 1, 1},		//16
		{0, 17, 1, 1, 1, 1, 1, 1, 1},		//17
		{1, 18, 1, 1, 1, 1, 1, 1, 1},		//18
		{1, 19, 1, 1, 1, 1, 1, 1, 1},		//19
		{1, 20, 1, 1, 1, 1, 1, 1, 1}		//20
								
};





//-----------------------------------------------------
//---		fecha y hora actual. leido de RTC	    ---
//-----------------------------------------------------

uint8_t tablaHoraActual[5]={00,00,0,1,1};

#define horaActual tablaHoraActual[0]
#define minutoActual tablaHoraActual[1]

int anoActual = 2016;
#define mesActual tablaHoraActual[3]
#define diaActual tablaHoraActual[4]





//-----------------------------------------------------
//---			definiciones para el menu			---
//-----------------------------------------------------

unsigned int menuPosX = 0;
unsigned int menuPosY = 0;

const int longMenuPpal=3;
int largoSubmenus[(longMenuPpal+1)]={0,2,20,3};
char teclaPulsada = '0';

int numeroDiasMes[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
uint8_t minutoAnterior;




//-----------------------------------------------------
//---					MISCELANEA					---
//-----------------------------------------------------
#define alarmPin 12

LiquidCrystal_I2C lcd(0X27,20,4);

char *monthName[12] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
char botonPulsado = '0';

#define RTCpinInt 2			//pin al que esta conectado la interrupcion del RTC
