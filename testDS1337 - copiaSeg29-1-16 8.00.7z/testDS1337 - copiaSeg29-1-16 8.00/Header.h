#define led 13

#define btnUp 22
#define btnDown 23
#define btnOk 24
#define btnC 25