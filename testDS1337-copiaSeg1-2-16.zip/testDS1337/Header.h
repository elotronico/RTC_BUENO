#define led 13
//-----------------------------------------------------
//---	    		TECLAS DEL TECLADO				---
//-----------------------------------------------------
#define delayPulsacion 160

#define btnUp 22
#define btnDown 23
#define btnOk 24
#define btnCancel 25



//-----------------------------------------------------
//---	    			astronomico.ino				---
//-----------------------------------------------------
// what is our longitude (west values negative) and latitude (south values negative)
float const LATITUDE = 42.22;
float const LONGITUDE = -8.81;
int zonaHoraria = 1;


uint8_t tablaOrtoOcaso[4] = {0,0,0,0};

#define horaAmanece tablaOrtoOcaso[0]
#define minutoAmanece tablaOrtoOcaso[1]

#define minutoAnochece tablaOrtoOcaso[2]
#define horaAnochece tablaOrtoOcaso[3]




//-----------------------------------------------------
//---		fecha y hora actual. leido de RTC	    ---
//-----------------------------------------------------

uint8_t tablaHoraActual[5]={10,15,2016,1,1};

#define horaActual tablaHoraActual[0]
#define minutoActual tablaHoraActual[1]

int anoActual = 2016;
#define mesActual tablaHoraActual[3]
#define diaActual tablaHoraActual[4]





//-----------------------------------------------------
//---			definiciones para el menu			---
//-----------------------------------------------------

unsigned int menuPosX = 0;
unsigned int menuPosY = 0;

const int longMenuPpal=4;
int largoSubmenus[(longMenuPpal+1)]={2,4,2,2,3};
char teclaPulsada = '0';

int numeroDiasMes[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
uint8_t minutoAnterior;




//-----------------------------------------------------
//---					MISCELANEA					---
//-----------------------------------------------------
#define alarmPin 12

LiquidCrystal_I2C lcd(0X27,16,2);

char *monthName[12] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
char botonPulsado = '0';
